export 'src/ed_screen_recorder/ed_screen_recorder_plugin.dart'
    show EdScreenRecorder;
