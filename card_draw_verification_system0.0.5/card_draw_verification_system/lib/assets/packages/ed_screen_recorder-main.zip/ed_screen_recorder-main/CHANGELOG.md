## 0.0.13
* Null Errors Fix
* Permission Errors Fix.

## 0.0.12
* Android OS save to gallery problem solved.

## 0.0.11
* Android library updated.
* Android pause and resume record feature added.

## 0.0.10
* Format.

## 0.0.9
* Custom File Path-Directory.

## 0.0.8
* IOS operating system support.
