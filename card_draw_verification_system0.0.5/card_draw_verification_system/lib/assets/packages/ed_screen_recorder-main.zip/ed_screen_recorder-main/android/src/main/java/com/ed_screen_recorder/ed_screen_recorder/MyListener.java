package com.ed_screen_recorder.ed_screen_recorder;

interface MyListener {
    void onCompleteCallback();

}