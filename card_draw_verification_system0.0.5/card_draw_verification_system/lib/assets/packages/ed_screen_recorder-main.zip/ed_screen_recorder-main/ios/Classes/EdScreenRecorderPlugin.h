#import <Flutter/Flutter.h>

@interface EdScreenRecorderPlugin : NSObject<FlutterPlugin>
@end
